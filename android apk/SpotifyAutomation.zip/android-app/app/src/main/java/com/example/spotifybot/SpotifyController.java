package com.example.spotifybot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Spotify UI automation using resource IDs from UI inspection (e.g. uiauto.dev).
 */
public class SpotifyController {

    private static final String TAG = "SpotifyController";
    private static final String SPOTIFY_PACKAGE = "com.spotify.music";

    // —— Resource IDs (from your Spotify UI dump) ——
    private static final String ID_QUERY = SPOTIFY_PACKAGE + ":id/query";
    private static final String ID_BUTTON_PLAY_PAUSE = SPOTIFY_PACKAGE + ":id/button_play_and_pause";
    private static final String ID_FEEDBACK_CONTAINER = SPOTIFY_PACKAGE + ":id/feedback_buttons_container";

    // Content descriptions / text
    private static final String DESC_NEXT = "Next";
    private static final String DESC_SHUFFLE = "Shuffle tracks";
    private static final String DESC_STOP_SHUFFLE = "Stop shuffling tracks";
    private static final String TEXT_FOLLOW = "Follow";

    private final Context context;
    private AtomicBoolean cancelToken;

    public SpotifyController(Context context) {
        this.context = context;
    }

    /** Allows BotService to cancel long-running loops (Stop session). */
    public void setCancelToken(AtomicBoolean token) {
        this.cancelToken = token;
    }

    private AccessibilityNodeInfo getRoot() {
        MyAccessibilityService service = MyAccessibilityService.getInstance();
        if (service == null) {
            Log.e(TAG, "Accessibility Service not connected");
            return null;
        }
        return service.getRootNode();
    }

    // —— Tree helpers ——
    private AccessibilityNodeInfo findFirstByViewId(String viewId) {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return null;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(viewId);
        if (nodes != null && !nodes.isEmpty()) {
            return nodes.get(0);
        }
        return null;
    }

    private boolean clickViewId(String viewId) {
        AccessibilityNodeInfo node = findFirstByViewId(viewId);
        if (node == null) return false;
        boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if (ok) Log.d(TAG, "Clicked view id: " + viewId);
        return ok;
    }

    /** Finds a node whose content description contains the given substring (case-insensitive). */
    private AccessibilityNodeInfo findNodeByContentDescContaining(AccessibilityNodeInfo node, String substring) {
        if (node == null || substring == null) return null;
        CharSequence cd = node.getContentDescription();
        if (cd != null && cd.toString().toLowerCase().contains(substring.toLowerCase())) {
            if (node.isClickable()) return node;
            AccessibilityNodeInfo clickable = findClickableAncestorOrSelf(node);
            if (clickable != null) return clickable;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo found = findNodeByContentDescContaining(child, substring);
                if (found != null) return found;
            }
        }
        return null;
    }

    private AccessibilityNodeInfo findClickableAncestorOrSelf(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        int depth = 0;
        while (n != null && depth++ < 8) {
            if (n.isClickable()) return n;
            n = n.getParent();
        }
        return node.isClickable() ? node : null;
    }

    private boolean clickContentDescContaining(String substring) {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return false;
        AccessibilityNodeInfo target = findNodeByContentDescContaining(root, substring);
        if (target == null) {
            Log.e(TAG, "No node with content desc containing: " + substring);
            return false;
        }
        boolean ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if (ok) Log.d(TAG, "Clicked content-desc ~ " + substring);
        return ok;
    }

    private boolean clickText(String text) {
        try {
            AccessibilityNodeInfo root = getRoot();
            if (root == null) return false;
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
            if (nodes != null && !nodes.isEmpty()) {
                for (AccessibilityNodeInfo n : nodes) {
                    if (n != null && n.isClickable()) {
                        boolean ok = n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        if (ok) {
                            Log.d(TAG, "Clicked text: " + text);
                            return true;
                        }
                    }
                }
                boolean ok = nodes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if (ok) Log.d(TAG, "Clicked text (first node): " + text);
                return ok;
            }
        } catch (Exception e) {
            Log.e(TAG, "clickText error: " + e.getMessage());
        }
        return false;
    }

    private boolean clickById(String id) {
        return clickViewId(id);
    }

    // —— Search tab (no stable id in your list — keep fallbacks, then use id/query) ——
    private boolean clickSearchTab() {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return false;

        String[] searchIds = {
                SPOTIFY_PACKAGE + ":id/search",
                SPOTIFY_PACKAGE + ":id/searchButton",
                SPOTIFY_PACKAGE + ":id/search_tab",
                SPOTIFY_PACKAGE + ":id/nav_search",
                SPOTIFY_PACKAGE + ":id/bottom_navigation_search",
                SPOTIFY_PACKAGE + ":id/action_search",
                SPOTIFY_PACKAGE + ":id/menu_search",
                "android:id/search_button",
                "android:id/menu_search"
        };
        for (String sid : searchIds) {
            if (clickById(sid)) return true;
        }
        if (clickText("Search")) return true;
        return clickContentDescContaining("Search");
    }

    /** Prefer com.spotify.music:id/query for typing. */
    public boolean search(String query) {
        try {
            Thread.sleep(800);

            AccessibilityNodeInfo input = findFirstByViewId(ID_QUERY);
            if (input == null) {
                if (!clickSearchTab()) {
                    Log.e(TAG, "Search entry not available");
                    return false;
                }
                Thread.sleep(1200);
                input = findFirstByViewId(ID_QUERY);
            }
            if (input == null) {
                Log.e(TAG, "query field not found: " + ID_QUERY);
                return false;
            }

            input.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            Thread.sleep(400);

            Bundle args = new Bundle();
            args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    query
            );
            input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            Thread.sleep(500);

            input.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            Thread.sleep(2000);

            Log.d(TAG, "Search submitted: " + query);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "search error: " + e.getMessage(), e);
            return false;
        }
    }

    public boolean searchViaUrl(String query) {
        try {
            String encodedQuery = query.replace(" ", "%20");
            String spotifyUrl = "https://open.spotify.com/search/" + encodedQuery;
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(spotifyUrl));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            Thread.sleep(3000);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "searchViaUrl failed: " + e.getMessage());
            return false;
        }
    }

    private boolean clickFirstResultRow() {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return false;
        String[] resultIds = {
                SPOTIFY_PACKAGE + ":id/result_row",
                SPOTIFY_PACKAGE + ":id/track_row",
                SPOTIFY_PACKAGE + ":id/entity_row"
        };
        for (String rid : resultIds) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(rid);
            if (nodes != null && !nodes.isEmpty()) {
                if (nodes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    Log.d(TAG, "Clicked first " + rid);
                    return true;
                }
            }
        }
        return false;
    }

    /** True if play/pause control shows Pause (i.e. something is playing) — does NOT click. */
    public boolean verifyPlaying() {
        try {
            Thread.sleep(1500);
            AccessibilityNodeInfo root = getRoot();
            if (root == null) return false;

            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(ID_BUTTON_PLAY_PAUSE);
            if (nodes != null && !nodes.isEmpty()) {
                CharSequence cd = nodes.get(0).getContentDescription();
                if (cd != null) {
                    String d = cd.toString().toLowerCase();
                    if (d.contains("pause")) {
                        Log.d(TAG, "Playback verified (Pause on control)");
                        return true;
                    }
                }
            }
            // Fallback: any node with pause in content-desc near now-playing
            AccessibilityNodeInfo byDesc = findNodeByContentDescContaining(root, "pause");
            if (byDesc != null) {
                Log.d(TAG, "Playback verified (pause in UI tree)");
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "verifyPlaying error: " + e.getMessage());
        }
        Log.e(TAG, "Not playing / could not verify");
        return false;
    }

    private boolean clickPlayControl() {
        if (clickViewId(ID_BUTTON_PLAY_PAUSE)) return true;
        if (clickText("Play")) return true;
        return false;
    }

    private boolean clickShuffleIfAvailable() {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return false;
        AccessibilityNodeInfo n = findNodeByContentDescContaining(root, DESC_SHUFFLE);
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            Log.d(TAG, "Clicked shuffle");
            return true;
        }
        n = findNodeByContentDescContaining(root, DESC_STOP_SHUFFLE);
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            Log.d(TAG, "Clicked stop shuffle (toggle)");
            return true;
        }
        return clickText("Shuffle");
    }

    public boolean openSpotify() {
        Log.d(TAG, "openSpotify()");
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(SPOTIFY_PACKAGE);
            if (intent == null) {
                Log.e(TAG, "Spotify not installed");
                return false;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            context.startActivity(intent);
            Thread.sleep(5000);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "openSpotify error: " + e.getMessage());
            return false;
        }
    }

    public boolean playArtist(String name) {
        try {
            if (!search(name)) return false;
            Thread.sleep(2000);

            if (clickText("Artists")) Thread.sleep(1500);

            if (!clickText(name)) {
                String fallback = name.split(" ")[0];
                if (!clickText(fallback) && !clickFirstResultRow()) {
                    Log.e(TAG, "Artist not found: " + name);
                    return false;
                }
            }

            Thread.sleep(2000);

            if (!clickPlayControl()) {
                if (clickShuffleIfAvailable()) {
                    Thread.sleep(1000);
                    clickPlayControl();
                }
            }

            Thread.sleep(2000);
            return verifyPlaying();
        } catch (Exception e) {
            Log.e(TAG, "playArtist error: " + e.getMessage(), e);
            return false;
        }
    }

    public boolean playSong(String songName) {
        try {
            if (!search(songName)) return false;
            Thread.sleep(2000);

            if (clickText("Songs")) Thread.sleep(1500);

            if (!clickText(songName)) {
                String fb = songName.split(" ")[0];
                if (!clickText(fb) && !clickFirstResultRow()) {
                    Log.e(TAG, "Song not found: " + songName);
                    return false;
                }
            }

            Thread.sleep(2000);
            return verifyPlaying();
        } catch (Exception e) {
            Log.e(TAG, "playSong error: " + e.getMessage(), e);
            return false;
        }
    }

    public boolean playPlaylist(String playlistName) {
        try {
            if (!search(playlistName)) return false;
            Thread.sleep(2000);

            if (clickText("Playlists")) Thread.sleep(1500);

            if (!clickText(playlistName)) {
                Log.e(TAG, "Playlist not found: " + playlistName);
                return false;
            }

            Thread.sleep(2000);
            clickShuffleIfAvailable();
            Thread.sleep(1000);
            clickPlayControl();

            return verifyPlaying();
        } catch (Exception e) {
            Log.e(TAG, "playPlaylist error: " + e.getMessage());
            return false;
        }
    }

    /**
     * Like: your dump maps heart area to feedback_buttons_container — try container then clickable child.
     */
    public boolean likeSong() {
        AccessibilityNodeInfo root = getRoot();
        if (root == null) return false;

        List<AccessibilityNodeInfo> containers = root.findAccessibilityNodeInfosByViewId(ID_FEEDBACK_CONTAINER);
        if (containers != null && !containers.isEmpty()) {
            AccessibilityNodeInfo c = containers.get(0);
            if (c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                Log.d(TAG, "Liked via feedback_buttons_container");
                return true;
            }
            AccessibilityNodeInfo child = findClickableChild(c);
            if (child != null && child.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                Log.d(TAG, "Liked via child of feedback_buttons_container");
                return true;
            }
        }

        if (clickText("Like") || clickText("Add to Liked Songs") || clickText("Save to your Liked Songs")) {
            return true;
        }

        Log.e(TAG, "Like failed");
        return false;
    }

    private AccessibilityNodeInfo findClickableChild(AccessibilityNodeInfo parent) {
        if (parent == null) return null;
        for (int i = 0; i < parent.getChildCount(); i++) {
            AccessibilityNodeInfo ch = parent.getChild(i);
            if (ch == null) continue;
            if (ch.isClickable()) return ch;
            AccessibilityNodeInfo deeper = findClickableChild(ch);
            if (deeper != null) return deeper;
        }
        return null;
    }

    public void likeMultipleSongs(int count) {
        try {
            for (int i = 0; i < count; i++) {
                if (cancelToken != null && cancelToken.get()) {
                    Log.d(TAG, "likeMultipleSongs cancelled");
                    return;
                }
                likeSong();
                randomDelay(3, 6);
                if (!clickContentDescContaining(DESC_NEXT)) {
                    clickText("Next");
                }
                Thread.sleep(2000);
                handlePopups();
                Log.d(TAG, "Liked " + (i + 1) + "/" + count);
            }
        } catch (Exception e) {
            Log.e(TAG, "likeMultipleSongs error: " + e.getMessage());
        }
    }

    public boolean followArtist(String name) {
        try {
            if (!search(name)) return false;
            Thread.sleep(2000);

            if (!clickText(name) && !clickFirstResultRow()) {
                Log.e(TAG, "Artist row not found");
                return false;
            }
            Thread.sleep(2000);

            if (clickText(TEXT_FOLLOW)) {
                Log.d(TAG, "Followed: " + name);
                return true;
            }
            if (clickText("Following")) {
                Log.d(TAG, "Already following");
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "followArtist error: " + e.getMessage());
        }
        return false;
    }

    public void randomDelay(int min, int max) {
        try {
            if (cancelToken != null && cancelToken.get()) return;
            int delay = min + (int) (Math.random() * (max - min));
            if (cancelToken != null && cancelToken.get()) return;
            Thread.sleep(delay * 1000L);
        } catch (Exception e) {
            Log.e(TAG, "randomDelay error: " + e.getMessage());
        }
    }

    public void handlePopups() {
        clickText("OK");
        clickText("Close");
        clickText("Not now");
        clickText("Got it");
        clickText("Allow");
    }

    public void printAllUIElements() {
        try {
            AccessibilityNodeInfo root = getRoot();
            if (root == null) {
                Log.e(TAG, "Root null");
                return;
            }
            Log.d(TAG, "========== UI dump ==========");
            printNodeRecursive(root, 0);
            Log.d(TAG, "==============================");
        } catch (Exception e) {
            Log.e(TAG, "printAllUIElements: " + e.getMessage());
        }
    }

    private void printNodeRecursive(AccessibilityNodeInfo node, int depth) {
        if (node == null) return;
        StringBuilder sb = new StringBuilder();
        for (int d = 0; d < Math.min(depth, 20); d++) sb.append("  ");
        String indent = sb.toString();
        String text = node.getText() != null ? node.getText().toString() : "";
        String className = node.getClassName() != null ? node.getClassName().toString() : "";
        String id = node.getViewIdResourceName() != null ? node.getViewIdResourceName() : "";
        String cd = node.getContentDescription() != null ? node.getContentDescription().toString() : "";
        Log.d(TAG, indent + className + " | text='" + text + "' | id=" + id + " | desc='" + cd + "'");

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                printNodeRecursive(child, depth + 1);
                child.recycle();
            }
        }
    }
}
